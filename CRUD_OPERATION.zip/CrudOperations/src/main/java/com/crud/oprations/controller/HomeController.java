package com.crud.oprations.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.crud.oprations.entity.Student;
import com.crud.oprations.repository.StudentRepository;

@RestController
public class HomeController {

	@Autowired
	private StudentRepository studentRepository;
	
	
	@GetMapping("/")
	public String index()
	{
		return "welcome to spring boot crud operations!!!";
	}
	
	
	//handler for creating new record in DB
	@PostMapping("/saveStudent")
	public Student saveSDate(@RequestBody Student student)
	{
		studentRepository.save(student);
		
		return student;
	}
	
	
	//handler for fetch all data from DB
	@GetMapping("/getAllStudents")
	public List<Student> getAll()
	{
		List<Student> studentList=studentRepository.findAll();
		
		return studentList;
	}
	
	//handler for delete a particular record from db
	@DeleteMapping("/deleteStudent/{rollNo}")
	public String deleteStudent(@PathVariable int rollNo)
	{
		Student student = studentRepository.findById(rollNo).get();
		if(student!=null)
			studentRepository.delete(student);
		return "Deleted Successfully!!";
	}
	
	//handler for updating a particular record
	@PutMapping("/updateData")
	public Student updateStudentData(@RequestBody Student student)
	{
     studentRepository.save(student);
	 return student;
	}
	
	//handler for fetch a single record
	@GetMapping("/getStudent/{rollNo}")
	public Student getStudentData(@PathVariable int rollNo)
	{
		Optional<Student> student = studentRepository.findById(rollNo);
		Student student1=student.get();
		return student1;
	}
	
	
}
